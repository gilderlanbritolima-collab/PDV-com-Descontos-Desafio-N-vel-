# PDV com Descontos — Desafio Nível 1

## O que o código faz

Este programa simula um PDV (Ponto de Venda) que calcula o valor final de cada compra aplicando dois descontos progressivos: um por idade do cliente e outro por valor da compra. Ele permite registrar várias compras seguidas, guarda todas em uma lista e, ao encerrar, exibe um resumo do dia com a quantidade de compras, o total bruto, o total de descontos concedidos e o total final.

## Como ele faz

1. Cria a lista `historico_compras`, que vai guardar todas as compras do dia.
2. Entra em um loop `while True` e pede o valor da compra. Se o usuário digitar `0`, o loop é encerrado com `break`.
3. Pede a idade do cliente.
4. Verifica se o valor ou a idade são negativos. Se forem, mostra uma mensagem de aviso e usa `continue` para voltar ao início do loop e pedir os dados novamente.
5. Se a idade for maior ou igual a 65, aplica 20% de desconto (valor × 0.8). Caso contrário, o valor segue igual.
6. Verifica se o valor já com o desconto de idade é maior que 100. Se for, aplica mais 10% (valor × 0.9) sobre esse valor.
7. Calcula o desconto concedido (valor original − valor final) e mostra o valor final no formato `R$ 144.00`, com duas casas decimais.
8. Guarda o valor original, o desconto e o valor final da compra na lista, usando `.append()`.
9. Ao sair do loop, usa `len()` para contar as compras e um `for` para somar o total bruto, o total de descontos e o total final.
10. Mostra o resumo do dia. Se nenhuma compra foi registrada, exibe uma mensagem informando isso.

## Como rodar

```
python pdv.py
```

Para encerrar o programa e ver o resumo, digite `0` no valor da compra.

## Tabela de exemplos

| # | Valor (R$) | Idade | Desconto idade | Desconto valor | Valor final esperado |
|---|-----------|-------|----------------|----------------|----------------------|
| 1 | 50.00 | 30 | 0% | 0% | R$ 50.00 |
| 2 | 100.00 | 30 | 0% | 0% | R$ 100.00 |
| 3 | 80.00 | 65 | 20% | 0% | R$ 64.00 |
| 4 | 100.00 | 70 | 20% | 0% | R$ 80.00 |
| 5 | 125.00 | 70 | 20% | 0% | R$ 100.00 |
| 6 | 200.00 | 30 | 0% | 10% | R$ 180.00 |
| 7 | 101.00 | 30 | 0% | 10% | R$ 90.90 |
| 8 | 200.00 | 65 | 20% | 10% | R$ 144.00 |
| 9 | 1000.00 | 80 | 20% | 10% | R$ 720.00 |
| 10 | 200.00 | 64 | 0% | 10% | R$ 180.00 |
