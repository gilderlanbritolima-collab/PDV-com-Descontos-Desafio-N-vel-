
historico_compras = []

print(" SISTEMA PDV - DESCONTOS PROGRESSIVOS ")
print("Digite 0 no valor da compra para encerrar o programa.\n")

while True:
    valor_original = float(input("Digite o valor da compra (R$): "))
    
    
    if valor_original == 0:
     break
        
    idade = int(input("Digite a idade do cliente: "))
    
   
    if valor_original < 0 or idade < 0:
        print("Aviso: O valor da compra e a idade não podem ser negativos. Tente novamente.\n")
        continue
        
   
    if idade >= 65:
        valor_com_desconto_idade = valor_original * 0.8
    else:
        valor_com_desconto_idade = valor_original
    
    if valor_com_desconto_idade > 100:
        valor_final = valor_com_desconto_idade * 0.9
    else:
        valor_final = valor_com_desconto_idade
        
    
    desconto_concedido = valor_original - valor_final
    
    
    print(f"Valor final: R$ {valor_final:.2f}\n")
    
    historico_compras.append([valor_original, desconto_concedido, valor_final])


print("\n=== RESUMO FINAL DO DIA ===")

quantidade_compras = len(historico_compras)

if quantidade_compras > 0:
    total_bruto = 0
    total_descontos = 0
    total_final = 0
    
    for compra in historico_compras:
        total_bruto += compra[0]
        total_descontos += compra[1]
        total_final += compra[2]
        
    print(f"Quantidade de compras registradas: {quantidade_compras}")
    print(f"Total bruto: R$ {total_bruto:.2f}")
    print(f"Total de descontos concedidos: R$ {total_descontos:.2f}")
    print(f"Total final: R$ {total_final:.2f}")
else:
    print("Nenhuma compra foi registrada.")

print("Programa encerrado com sucesso!")